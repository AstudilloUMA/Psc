/**
UNIX Shell Project

Sistemas Operativos
Grados I. Informatica, Computadores & Software
Dept. Arquitectura de Computadores - UMA

Some code adapted from "Fundamentos de Sistemas Operativos", Silberschatz et al.

To compile and run the program:
   $ gcc Shell_project.c job_control.c -o Shell
   $ ./Shell
	(then type ^D to exit program)

**/

#include "job_control.h" // remember to compile with module job_control.c
#include <string.h>

#define MAX_LINE 256 /* 256 chars per line, per command, should be enough. */

job *my_job_list;
// -----------------------------------------------------------------------
//                            MAIN
// -----------------------------------------------------------------------

void handler_SIGCHLD(int signal)
{
	job_iterator iter;
	job *the_job;
	int pid_wait, status, info;
	enum status status_res;

	iter = get_iterator(my_job_list);
	while (has_next(iter))
	{
		the_job = next(iter);
		pid_wait = waitpid(the_job->pgid, &status, WNOHANG | WUNTRACED | WCONTINUED);
		if (pid_wait == the_job->pgid)
		{
			status_res = analyze_status(status, &info);
			printf("Background pid: %d, command: %s, %s, info: %d\n",
				   the_job->pgid, the_job->command, status_strings[status_res], info);
			// SUSPENDED, SIGNALED, EXITED, CONTINUED
			if (status_res == SIGNALED || status_res == EXITED)
			{
				delete_job(my_job_list, the_job);
			}
			else
			{
				if (status_res == SUSPENDED)
				{
					the_job->state = STOPPED;
				}
				else
				{
					if (status_res == CONTINUED)
					{
						the_job->state = BACKGROUND;
					}
				}
			}
		}
	}
}

int main(void)
{
	char inputBuffer[MAX_LINE]; /* buffer to hold the command entered */
	int background;				/* equals 1 if a command is followed by '&' */
	char *args[MAX_LINE / 2];	/* command line (of 256) has max of 128 arguments */
	// probably useful variables:
	int pid_fork, pid_wait; /* pid for created and waited process */
	int status;				/* status returned by wait */
	enum status status_res; /* status processed by analyze_status() */
	int info;			/* info processed by analyze_status() */

	ignore_terminal_signals();
	signal(SIGCHLD, handler_SIGCHLD);
	my_job_list = new_list("Shell jobs");
	
	job * the_job;
	char * comando;

	while (1) /* Program terminates normally inside get_command() after ^D is typed*/
	{
		printf("COMMAND->");
		fflush(stdout);
		get_command(inputBuffer, MAX_LINE, args, &background); /* get next command */

		if (args[0] == NULL)
			continue; // if empty command

		/* the steps are:
			 (1) fork a child process using fork()
			 (2) the child process will invoke execvp()
			 (3) if background == 0, the parent will wait, otherwise continue
			 (4) Shell shows a status message for processed command
			 (5) loop returns to get_commnad() function
		*/
		
		comando = args[0];

		if (!strcmp(comando, "jobs"))
		{ // Comando interno jobs
			block_SIGCHLD();
			print_job_list(my_job_list);
			unblock_SIGCHLD();
			continue;
		}
		
			
			if (!strcmp(comando, "cd"))
			{ // Comando interno CD
			
				if (chdir(args[1])) printf("Directory %s does not exist\n", args[1]);
				continue;
				
			} 
			
			if (!strcmp(comando, "bg")) {					//comprobamos si el usuario a introducido bg
				block_SIGCHLD();
				
				int pos = 1;
				if (args[1] != NULL) pos = atoi(args[1]);		// transformamos el siguiente argumento a int
				the_job = get_item_bypos(my_job_list, pos);		// sacamos el proceso por la posicion
				if ((the_job != NULL) && (the_job->state == STOPPED)){
				
					the_job->state = BACKGROUND;
					killpg(the_job->pgid, SIGCONT);
					
				}
				unblock_SIGCHLD();
				
				continue;
	
			}
			
			if (!strcmp(comando, "fg")) {
				
				block_SIGCHLD();
			
				int pos = 1;
				if (args[1] != NULL) pos = atoi(args[1]);		// transformamos el siguiente argumento a int
				the_job = get_item_bypos(my_job_list, pos);
				
				if(the_job != NULL) {
				
					set_terminal(the_job->pgid);
					if (the_job->state == STOPPED){
			
						killpg(the_job->pgid, SIGCONT);
					}
					pid_fork = the_job->pgid;
					comando = strdup(the_job->command);
					delete_job(my_job_list, the_job);
				
				}
				
				if (pid_fork == -1)
			{ // Fallo fork
				printf("Fork error: %s\n", comando);
			}
			else
			{
				//printf("%d\n",pid_fork);
				if (pid_fork == 0)
				{ // Proceso hijo
					new_process_group(getpid());
					if (!background) set_terminal(getpid());
					restore_terminal_signals();
					execvp(comando, args);
					printf("Error, command not found: %s\n", comando);
					exit(-1);
				}
				else
				{ // Proceso padre
					new_process_group(pid_fork);
					if (background)
					{ // background
						printf("Background job running... pid: %d, command: %s\n", pid_fork, comando);
						block_SIGCHLD();
						add_job(my_job_list, new_job(pid_fork, comando, background));
						unblock_SIGCHLD();
					}
					else
					{ // Foreground
						set_terminal(pid_fork);
						pid_wait = waitpid(pid_fork, &status, WUNTRACED);
						set_terminal(getpid());
						if (pid_wait == pid_fork)
						{
							status_res = analyze_status(status, &info);
							printf("Foreground pid: %d, command: %s, %s, info: %d\n",
							pid_fork, comando, status_strings[status_res], info);
							if (status_res == SUSPENDED)
							{
								block_SIGCHLD();
								add_job(my_job_list, new_job(pid_fork, comando, STOPPED));
								unblock_SIGCHLD();
							}
						}

					}
				}
			}
				
				unblock_SIGCHLD();
				continue;
				
	
			} else {
			

			 // Comandos externos
			pid_fork = fork();
			if (pid_fork == -1)
			{ // Fallo fork
				printf("Fork error: %s\n", comando);
			}
			else
			{
				//printf("%d\n",pid_fork);
				if (pid_fork == 0)
				{ // Proceso hijo
					new_process_group(getpid());
					if (!background) set_terminal(getpid());
					restore_terminal_signals();
					execvp(comando, args);
					printf("Error, command not found: %s\n", comando);
					exit(-1);
				}
				else
				{ // Proceso padre
					new_process_group(pid_fork);
					if (background)
					{ // background
						printf("Background job running... pid: %d, command: %s\n", pid_fork, comando);
						block_SIGCHLD();
						add_job(my_job_list, new_job(pid_fork, comando, background));
						unblock_SIGCHLD();
					}
					else
					{ // Foreground
						set_terminal(pid_fork);
						pid_wait = waitpid(pid_fork, &status, WUNTRACED);
						set_terminal(getpid());
						if (pid_wait == pid_fork)
						{
							status_res = analyze_status(status, &info);
							printf("Foreground pid: %d, command: %s, %s, info: %d\n",
							pid_fork, comando, status_strings[status_res], info);
							if (status_res == SUSPENDED)
							{
								block_SIGCHLD();
								add_job(my_job_list, new_job(pid_fork, comando, STOPPED));
								unblock_SIGCHLD();
							}
						}

					}
				}
				
				continue;
			}
			
		}


	} // end while
}
