/*
 * Sistema.c
 *
 *  Created on: 9 mar 2023
 *      Author: Remoto
 */
#include "Sistema.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void Crear(LSistema *l){
	*l = NULL;
}

void InsertarProceso ( LSistema *ls, int numproc){
	LSistema nuevo = (LSistema) malloc(sizeof(struct NodoProceso));
	if(nuevo != NULL){
		nuevo->pid = numproc;
		nuevo->sig =NULL;
		nuevo->hebras =NULL;

		if(*ls == NULL){
			*ls = nuevo;
		}else{
			LSistema aux = *ls;
			while(aux->sig !=NULL){
				aux = aux->sig;
			}
			aux->sig = nuevo;
		}
	}else{
		perror("InsertarProceso: no se puede reservar memoria");
	}
}

void InsertarHebra (LSistema *ls, int numproc, char *idhebra, int priohebra){
	LSistema auxP = *ls;
	LHebras auxH = NULL, antH=NULL;
	LHebras nuevaH = (LHebras)malloc(sizeof(struct NodoHebra));
	if(nuevaH != NULL){
		nuevaH->prio = priohebra;
		strcpy(nuevaH->hid, idhebra);
		while(auxP != NULL  && auxP->pid != numproc){
			auxP = auxP->sig;
		}

		auxH = auxP->hebras;

		while(auxH != NULL && auxH->prio > priohebra){
			antH = auxH;
			auxH = auxH->sig;
		}
		nuevaH->sig = auxH;
		if(antH == NULL){
			auxP->hebras = nuevaH;
		}else{
			antH->sig = nuevaH;
		}
	}else{
		perror("InsertarHebra: no se puede reservar memoria");
	}

}


void MostrarH (LHebras lh){
	printf("Hebras: ");
	while(lh != NULL){
		printf("(%s , %d) ", lh->hid, lh->prio);
		lh = lh->sig;
	}
}

void Mostrar (LSistema ls){
	printf("\nLista procesos:");
	while(ls !=NULL){
		printf("\npid %d \n", ls->pid);
		MostrarH(ls->hebras);
		ls = ls->sig;
	}

}

void EliminarHebras (LHebras *lh){
	LHebras aux;
	while(*lh != NULL){
		aux = *lh;
		*lh = (*lh)->sig;
		free(aux);
	}
}
void EliminarProc (LSistema *ls, int numproc){
	/*En esta implementacion suponemos que el proceso numproc esta en la lista y que el pdi es unico.
	 * Si no es asi habria que comprobar al salir del while que aux != NULL*/
	LSistema ant = NULL, aux= *ls;
	while(aux!=NULL && aux->pid != numproc){
		ant = aux;
		aux = aux->sig;
	}
	if(ant == NULL){
		*ls = aux->sig;
	}else{
		ant->sig = aux->sig;
	}
	EliminarHebras(&(aux->hebras));
	free(aux);
}

//Destruye toda la estructura liberando su memoria
void Destruir (LSistema *ls){
	LSistema aux;
	while(*ls!=NULL){
		aux = *ls;
		*ls= (*ls)->sig;
		EliminarHebras(&(aux->hebras));
		free(aux);
	}
}

void SalvarTexto(LSistema ls, char *nombreFich){
	FILE *f = fopen(nombreFich, "wt");
	if(f!=NULL){
		while(ls !=NULL){
			fprintf(f, "pid %d: ", ls->pid);
			LHebras auxH = ls->hebras;
			/*Tenemos que usar un puntero aux para recorrer las hebras,
			 * si no estariamos cambiando el la lista de hebras del nodo
			 * y perderiamos nodos sin liberar la memoria*/
			while(auxH != NULL){
				fprintf(f, "(%s , %d) ", auxH->hid, auxH->prio);
				auxH = auxH->sig;
			}
			fprintf(f,"\n");
			ls = ls->sig;
		}
		fclose(f);
	}else{
		perror("SalvarTexto: Error al abrir fichero binario");
	}


}

int contarHebras(LHebras lh){
	int contador = 0;
	while(lh!= NULL){
		contador ++;
		lh = lh->sig;
	}
	return contador;
}
void SalvarBinario(LSistema ls, char *nombreFich){
	FILE *f = fopen(nombreFich, "wb");
	if(f!=NULL){
		while(ls != NULL){
			fwrite( &(ls->pid), sizeof(int), 1, f);
			int tam = contarHebras(ls->hebras);
			fwrite(&tam, sizeof(int),1, f);
			LHebras auxH = ls->hebras;
			while(auxH != NULL){
				int len = strlen(auxH->hid);
				fwrite(&len, sizeof(int), 1, f);
				fwrite(auxH->hid, sizeof(char), len,f);
				fwrite(&(auxH->prio), sizeof(int), 1, f);
				auxH = auxH->sig;
			}
			ls = ls->sig;
		}
		fclose(f);
	}else{
		perror("SalvarBinario: Error al abrir fichero binario");
	}
}

void CargarFicheroBinario(LSistema *ls, char *nombreFich){
	int pid, prio, numH, len, i;
	char hid[3];
	FILE *f = fopen(nombreFich, "rb");
	if(f!=NULL){
		while(!feof(f)){
			fread(&pid, sizeof(int),1,f);
			InsertarProceso(ls,pid);
			fread(&numH, sizeof(int),1,f);
			for( i = 0; i < numH; i++){
				fread(&len, sizeof(int),1,f);
				fread(hid,sizeof(char), len,f);
				hid[len]= '\0';
				fread(&prio,sizeof(int),1,f);
				InsertarHebra(ls,pid,hid,prio);
			}

		}
		fclose(f);
	}else{
		perror("CargarFicheroBinario: Error al abrir fichero binario");
	}

}

