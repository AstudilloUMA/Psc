/*
 * Mprocesos.c
 *
 *  Created on: 1 mar 2023
 *      Author: Remoto
 */

#include <stdio.h>
#include <stdlib.h>
#include "Mprocesos.h"

void Crear(LProc *lroundrobin){
	*lroundrobin = NULL;
}

void AnadirProceso(LProc *lroundrobin, int idproc){
	LProc nuevo = (LProc)malloc(sizeof(struct T_Nodo));
	if(nuevo==NULL){
		perror("AnadirProceso: Error al reservar memoria");
	}else{
		nuevo->pid =idproc;

		if(*lroundrobin == NULL){
			*lroundrobin = nuevo;
			nuevo->sig = nuevo;
		}else{
			nuevo->sig = (*lroundrobin)->sig;
			(*lroundrobin)->sig = nuevo;
			(*lroundrobin) = nuevo;
		}
	}
}

void EjecutarProcesos(LProc lroundrobin){
	LProc actual;

	if(lroundrobin == NULL){
		printf("Lista vacía\n");
	}else{
		actual = lroundrobin->sig;
		do{
			printf("Proceso %d en ejecucion\n", actual->pid);
			actual = actual->sig;
		}while(actual!= lroundrobin->sig);
	}
}

void EliminarProceso(int id, LProc *lista){
	if(*lista == (*lista)->sig){
		free(*lista);
		*lista =NULL;
	}else{
		LProc actual = (*lista)->sig;
		LProc anterior = *lista;
		do{
			anterior = actual;
			actual = actual->sig;
		}while(actual!= (*lista)->sig && actual->pid != id);

		anterior->sig = actual->sig;
		if(actual == *lista){
			*lista = anterior;
		}

		free(actual);
	}
}

// Función auxiliar para contar el número de procesos en la lista
int tamanio(LProc lista){
	LProc actual;
	int tam = 0;
	if(lista != NULL){
		 actual= lista->sig;
		 do{
			 tam++;
			 actual = actual->sig;
		 }while(actual != lista->sig);
	}
	return tam;
}

void EscribirFichero (char * nomf, LProc *lista){
	int tam,i;
	LProc aux;
	FILE *f = fopen(nomf,"wb");

	if(f == NULL){
		perror("EscribirFichero: error al abrir fichero");
	}else{
		tam = tamanio(*lista);
		fwrite(&tam, sizeof(int), 1, f);

		for(i = 0; i < tam; i++){
			aux = (*lista)->sig;
			fwrite(&(aux->pid), sizeof(int), 1, f);
			(*lista)->sig = aux->sig;
			free(aux);
		}
		*lista = NULL;
		fclose(f);
	}
}
