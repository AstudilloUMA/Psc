#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Componentes.h"

Lista Lista_Crear(){
	Lista memoria = NULL;
	return memoria;
}

void Adquirir_Componente(long *codigo,char *texto){
	printf("Introduzca ahora el código del componente:\n");
	scanf("%ld", codigo);
	printf("Introduzca ahora el texto del componente:\n");
	scanf("%s", texto);
}

void Lista_Agregar(Lista *lista, long codigo, char* textoFabricante){
	if ((*lista) == NULL){
		Componente* nodoAct = (Componente*)malloc(sizeof(struct elemLista));
		(nodoAct) -> codigoComponente = codigo;
		(nodoAct) -> sig = NULL;
		strncpy(nodoAct->textoFabricante, textoFabricante, 33);
		(*lista) = nodoAct;
	} else{
		Componente* nodoAct = (*lista);
		while(nodoAct -> sig != NULL){
			nodoAct = nodoAct -> sig;
		}
		Componente* nuevoNodo = (Componente*)malloc(sizeof(struct elemLista));
		nuevoNodo -> codigoComponente = codigo;
		nuevoNodo -> sig = NULL;
		strncpy(nuevoNodo->textoFabricante, textoFabricante, 33);
		nodoAct -> sig = nuevoNodo;
	}
}

void Lista_Imprimir( Lista lista){
	if (lista == NULL){
		printf("Lista vacia ciela\n");
	} else {
		Componente* nodoAct = lista;
		while(nodoAct != NULL){
			printf("Listando componente %ld ", nodoAct -> codigoComponente);
			printf("%s\n", nodoAct -> textoFabricante);
			nodoAct = nodoAct -> sig;
		}
	}
}

int Lista_Vacia(Lista lista){
	int res = 1;
	if (lista != NULL){
		res = 0;
	}
	return res;
}

int Num_Elementos(Lista  lista){
	int num = 0;
	if (lista != NULL){
		Componente* nodoAct = lista;
		while(nodoAct -> sig != NULL){
			nodoAct = nodoAct -> sig;
			num++;
		}
	num++;
	}
	return num;
}

void Lista_Extraer(Lista *lista){
	if ((*lista) != NULL){
		Componente* nodoAct = (*lista);
		Componente* nodoSig = nodoAct -> sig;
		if (nodoSig == 	NULL){
			(*lista) = NULL;
			free(nodoAct);
		} else{
			while(nodoSig -> sig != NULL){
				nodoAct = nodoSig;
				nodoSig = nodoSig -> sig;
			}
			nodoAct -> sig = NULL;
			free(nodoSig);
		}
		
	}
}

void Lista_Vaciar(Lista *lista){
	while (*lista != NULL){
		Lista_Extraer(lista);
	}
}

void Lista_Salvar( Lista  lista){

	FILE * fichero = fopen("examen.dat", "wb");

	if (lista == NULL){
		fwrite("La lista esta vacia ciela\n", sizeof(char), 19, fichero);
	} else {
		Componente* nodoAct = lista;
		while(nodoAct -> sig != NULL){
			fwrite("Listando componente ", sizeof(char), 20, fichero);
			fwrite(&nodoAct -> codigoComponente, sizeof(long), 1, fichero);
			fwrite("\n", sizeof(char), 1, fichero);
			nodoAct = nodoAct -> sig;
		}
		fwrite("Listando componente ", sizeof(char), 20, fichero);
		fwrite(&nodoAct -> codigoComponente, sizeof(long), 1, fichero);
		fwrite("\n", sizeof(char), 1, fichero);
	}

	fclose(fichero);

}